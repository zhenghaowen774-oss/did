# -*- coding: utf-8 -*-
"""
================================================================================
绿色信贷指引 × 资本错配 —— DID Baseline 演示代码（教学版）
================================================================================
一、这段代码在干什么
    用"倍差法(Difference-in-Differences, DID)"检验《绿色信贷指引》(2012)是否
    改变了重污染行业企业的"资本错配"程度。

    回归方程（Baseline）：
        Y_it = β · (Treat_i × Post_t) + μ_i + λ_t + ε_it

        Y       = 资本错配（借贷成本楔子，学生已算好，取绝对值）
        Treat_i = 1 若企业属于重污染行业（处置组），否则 0（对照组）
        Post_t  = 1 若年份 >= 2012（政策后），否则 0（政策前）
        Treat×Post = 交乘项，β 就是 DID 估计量（我们最关心的系数）
        μ_i     = 企业固定效应（吸收企业不随时间变的差异）
        λ_t     = 年份固定效应（吸收宏观经济随时间变的影响）

二、使用前提
    1. 装好依赖：pip install pandas numpy statsmodels linearmodels openpyxl
    2. 把两个原始文件放在本脚本同一目录：
         行业分类 2009-2011.xlsx
         行业分类 2012-2014.xlsx
    3. 直接运行：python DID_baseline_演示.py

三、输出
    - 控制台打印：样本描述、2×2 DID 表、DID 回归结果
    - 文件：did_panel_cleaned.csv （清洗后的企业-年面板，可拿去给 Stata 用）
    - 文件：did_baseline_result.txt （baseline 回归结果存档）

四、⚠️ 三个必须向老师交代的注意点（代码里都有对应提示）
    1. 行业分类在 2009-2011（旧版）与 2012-2014（证监会2012版）之间口径不同，
       处理组用"二级行业关键词"识别，可跨两套口径；但正式论文建议统一行业代码。
    2. 企业标识目前只有"股票简称"，会因更名/ST 而断裂；正式论文务必用"股票代码"。
    3. 本 baseline 只含 Treat×Post + 双固定效应，无控制变量；正式回归要加
       规模、杠杆、ROA、企业年龄、产权性质等。
================================================================================
"""

import glob
import re
import sys

import numpy as np
import pandas as pd

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

from linearmodels.panel import PanelOLS

# ==============================================================================
# 0. 配置区（需要改的地方都在这）
# ==============================================================================
POLICY_YEAR = 2012                     # 绿色信贷指引 2012 年发布
PRE = (2009, 2011)                     # 政策前窗口
POST = (2012, 2014)                    # 政策后窗口

# 重污染行业关键词（依据《上市公司环保核查行业分类管理名录》16 类重污染行业，
# 匹配到"二级行业名称"子串；可跨 2009-2011 旧分类与 2012-2014 新分类两套口径）。
# 注意：这是教学用占位定义，正式论文请换成导师给的重污染行业代码名单。
HEAVY_POLLUTION_KEYWORDS = [
    "煤炭", "石油", "化学", "化工", "炼焦", "黑色金属", "有色金属", "冶炼",
    "水泥", "非金属矿物", "造纸", "纺织", "制革", "皮毛", "医药", "制药",
    "采矿", "采选", "采掘", "电力", "火电", "金属、非金属", "建材",
]

# 是否对资本错配 Y 做 1%/99% 缩尾（baseline 建议 True，避免极端值主导回归）
WINSORIZE_Y = True
WINSOR_LOWER, WINSOR_UPPER = 0.01, 0.01


# ==============================================================================
# 1. 读取 6 个 sheet -> 企业-年长面板
# ==============================================================================
# 每个 sheet 的列位置不一样，这里用一个映射表写死（name, 一级行业, 二级行业,
# rit, 带符号楔子, 资本错配绝对值）。
SHEET_LAYOUT = {
    ("old", "2009"): (2, 3, 4, 5, 7, 8),
    ("old", "2010"): (0, 1, 2, 3, 5, 6),
    ("old", "2011"): (0, 1, 2, 3, 5, 6),
    ("new", "2012"): (1, 2, 3, 4, 6, 7),
    ("new", "2013"): (1, 2, 3, 4, 6, 7),
    ("new", "2014"): (1, 2, 3, 4, 5, 6),
}


def clean_name(x):
    """清洗股票简称：去掉 *ST / ST / S 前缀与空格，用于跨年匹配同一家企业。

    注意：这只是权宜之计（更名/借壳仍会断），正式论文务必用股票代码。
    """
    s = str(x).strip()
    s = re.sub(r"^(\*?\s*S\s*T|S\s*T|\*ST|ST)", "", s)
    return s.strip()


def build_panel():
    f_old = [f for f in glob.glob("*.xlsx") if "2009" in f]
    f_new = [f for f in glob.glob("*.xlsx") if "2012" in f]
    if not f_old or not f_new:
        raise FileNotFoundError(
            "找不到原始文件。请把『行业分类 2009-2011.xlsx』和"
            "『行业分类 2012-2014.xlsx』放到本脚本同目录。")

    frames = []
    for (key, sheet), (nc, i1, i2, rc, wc, mc) in SHEET_LAYOUT.items():
        f = f_old[0] if key == "old" else f_new[0]
        raw = pd.read_excel(f, sheet_name=sheet, header=None)
        d = raw.iloc[1:]                      # 第 0 行是表头，数据从第 1 行起
        frames.append(pd.DataFrame({
            "year": int(sheet),
            "name_raw": d[nc].astype(str),
            "ind1": d[i1].astype(str),
            "ind2": d[i2].astype(str),
            "rit": pd.to_numeric(d[rc], errors="coerce"),
            "mis": pd.to_numeric(d[mc], errors="coerce"),
        }))

    df = pd.concat(frames, ignore_index=True)
    df["firm"] = df["name_raw"].apply(clean_name)
    df = df.dropna(subset=["mis"])            # Y 缺失的观测先剔除
    df = df[df["year"].between(PRE[0], POST[1])]
    return df


# ==============================================================================
# 2. 定义 Treat 与 Post
# ==============================================================================
def define_vars(df):
    def is_heavy(ind2):
        ind2 = str(ind2)
        return any(k in ind2 for k in HEAVY_POLLUTION_KEYWORDS)

    df["treat"] = df["ind2"].apply(is_heavy).astype(int)
    df["post"] = (df["year"] >= POLICY_YEAR).astype(int)
    df["did"] = df["treat"] * df["post"]
    return df


# ==============================================================================
# 3. 缩尾 Y（可选）
# ==============================================================================
def winsorize_y(df):
    if not WINSORIZE_Y:
        return df
    lo = df["mis"].quantile(WINSOR_LOWER)
    hi = df["mis"].quantile(1 - WINSOR_UPPER)
    df["Y"] = df["mis"].clip(lo, hi)
    print("[缩尾] Y 的 1%%/99%% 分位数 = %.4f / %.4f，已夹到该区间。" % (lo, hi))
    return df


# ==============================================================================
# 4. 2×2 DID 表（直觉核心）
# ==============================================================================
def did_table(df):
    t = df["treat"] == 1
    p = df["post"] == 1
    m_pre_t = df.loc[t & ~p, "Y"].mean()
    m_post_t = df.loc[t & p, "Y"].mean()
    m_pre_c = df.loc[~t & ~p, "Y"].mean()
    m_post_c = df.loc[~t & p, "Y"].mean()

    did = (m_post_t - m_pre_t) - (m_post_c - m_pre_c)

    print("\n" + "=" * 68)
    print("[4] 2×2 DID 表：Y（资本错配）的组均值")
    print("=" * 68)
    print("                政策前(%d-%d)   政策后(%d-%d)   一阶差分" %
          (PRE[0], PRE[1], POST[0], POST[1]))
    print("  对照组(非重污染)   %8.4f       %8.4f      %+8.4f" %
          (m_pre_c, m_post_c, m_post_c - m_pre_c))
    print("  处置组(重污染)     %8.4f       %8.4f      %+8.4f" %
          (m_pre_t, m_post_t, m_post_t - m_pre_t))
    print("-" * 68)
    print("  DID = (处置组变化) − (对照组变化) = %+8.4f" % did)
    print("  含义：β>0 表示重污染企业错配相对上升；β<0 表示相对下降。")
    return did


# ==============================================================================
# 5. DID 回归（Baseline）
# ==============================================================================
def run_regressions(df):
    panel = df.set_index(["firm", "year"])
    y = panel["Y"]
    X = panel[["did"]]                    # 只放交乘项；Treat/Post 被固定效应吸收

    print("\n" + "=" * 68)
    print("[5] Baseline 回归：Y = β·(Treat×Post) + 企业FE + 年份FE")
    print("=" * 68)

    # (a) 朴素 OLS：不控制固定效应（用来对照，说明为什么必须加 FE）
    from statsmodels.api import OLS
    X_naive = panel[["treat", "post", "did"]]
    X_naive = X_naive.assign(const=1.0)
    naive = OLS(y, X_naive).fit(cov_type="HC1")

    # (b) 双固定效应（Baseline，标准做法）
    mod = PanelOLS(y, X, entity_effects=True, time_effects=True,
                   drop_absorbed=True)
    res = mod.fit(cov_type="clustered", cluster_entity=True)

    # (c) 仅企业固定效应（不加年份 FE，看差别）
    mod_fe = PanelOLS(y, X, entity_effects=True, drop_absorbed=True)
    res_fe = mod_fe.fit(cov_type="clustered", cluster_entity=True)

    def show(name, r):
        # statsmodels 与 linearmodels 的系数/标准误属性名不同，这里统一取
        se = r.std_errors["did"] if hasattr(r, "std_errors") else r.bse["did"]
        t = r.tstats["did"] if hasattr(r, "tstats") else r.tvalues["did"]
        b = r.params["did"]
        p = r.pvalues["did"]
        n = int(r.nobs)
        stars = "***" if p < 0.01 else ("**" if p < 0.05 else ("*" if p < 0.1 else ""))
        print("  %-22s β=%+8.4f  se=%.4f  t=%+6.2f  p=%.4f  N=%d  %s" %
              (name, b, se, t, p, n, stars))

    show("朴素OLS(无FE)", naive)
    show("仅企业FE", res_fe)
    show("企业FE+年份FE(基准)", res)

    print("-" * 68)
    print("  看『企业FE+年份FE(基准)』这一行的 β 和 p 值：")
    print("   β 显著 ≠ 0  -> 绿色信贷确实改变了重污染企业的资本错配；")
    print("   符号为正/负  -> 分别代表错配上升/下降。")
    return res


# ==============================================================================
# 6. 主流程
# ==============================================================================
def main():
    df = build_panel()
    df = define_vars(df)
    print("=" * 68)
    print("[样本] 企业-年观测：%d 条；唯一企业：%d 家" % (len(df), df["firm"].nunique()))
    print("       处置组(重污染) %d 条；对照组 %d 条" %
          ((df["treat"] == 1).sum(), (df["treat"] == 0).sum()))
    print("       政策前 %d 条；政策后 %d 条" %
          ((df["post"] == 0).sum(), (df["post"] == 1).sum()))

    # 关键诊断：有多少企业跨了政策前后两个窗口（识别 DID 的来源）
    spans = df.groupby("firm")["post"].nunique()
    print("       跨政策前后两窗口的企业：%d 家（DID 的识别来源）" %
          (spans[spans == 2].shape[0]))

    df = winsorize_y(df)
    did_table(df)

    # 输出清洗后面板（供 Stata / 老师复用）
    keep = ["firm", "name_raw", "year", "ind1", "ind2", "treat", "post",
            "did", "rit", "mis", "Y"]
    df[keep].to_csv("did_panel_cleaned.csv", index=False, encoding="utf-8-sig")

    res = run_regressions(df)

    # 存档回归结果
    with open("did_baseline_result.txt", "w", encoding="utf-8") as fh:
        fh.write(str(res.summary))
    print("\n[输出] 已生成 did_panel_cleaned.csv 与 did_baseline_result.txt")
    print("\n" + str(res.summary.tables[1]))


if __name__ == "__main__":
    main()
