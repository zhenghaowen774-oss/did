#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""读取实际运行结果，生成中文Word、HTML、Markdown报告和独立PNG/PDF图。"""
from __future__ import annotations
import argparse
import base64
import html
import json
import os
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR','/tmp/did_matplotlib')
os.environ.setdefault('XDG_CACHE_HOME','/tmp/did_cache')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from docx import Document
from docx.shared import Inches,Pt,Cm,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

def f(x,d=4):
    return '—' if pd.isna(x) else f'{x:.{d}f}'

def pf(x):
    return '<0.001' if x<.001 else f(x,3)


class Report:
    def __init__(self,out):
        self.out=out;self.doc=Document();self.md=[];self.web=[]
        sec=self.doc.sections[0]
        sec.page_width=Cm(21);sec.page_height=Cm(29.7)
        sec.top_margin=sec.bottom_margin=Cm(1.8)
        sec.left_margin=sec.right_margin=Cm(1.8)
        normal=self.doc.styles['Normal'];normal.font.name='Calibri';normal.font.size=Pt(10)
        normal.element.rPr.rFonts.set(qn('w:eastAsia'),'微软雅黑')
        normal.paragraph_format.space_after=Pt(6)
        for style in ['Title','Heading 1','Heading 2']:
            self.doc.styles[style].font.name='Calibri'
            self.doc.styles[style].element.rPr.rFonts.set(qn('w:eastAsia'),'微软雅黑')
        self.doc.styles['Title'].font.size=Pt(22)
        footer=sec.footer.paragraphs[0];footer.alignment=2
        footer.add_run('绿色信贷与资本错配 | ')
        field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');footer._p.append(field)

    def title(self,s):
        self.doc.add_heading(s.replace('：完整 DID 分析','\n完整 DID 分析'),0)
        self.md.append('# '+s);self.web.append('<h1>'+html.escape(s)+'</h1>')

    def h(self,s):
        self.doc.add_heading(s,1);self.md.append('\n## '+s);self.web.append('<h2>'+html.escape(s)+'</h2>')

    def p(self,s):
        self.doc.add_paragraph(s);self.md.append(s);self.web.append('<p>'+html.escape(s)+'</p>')

    def table(self,df,caption=None):
        df=df.copy().fillna('—').astype(str)
        if caption:self.p(caption)
        table=self.doc.add_table(rows=1,cols=len(df.columns));table.style='Light Shading Accent 1'
        for i,c in enumerate(df.columns):table.rows[0].cells[i].text=str(c)
        for row in df.itertuples(index=False,name=None):
            cells=table.add_row().cells
            for i,value in enumerate(row):cells[i].text=value
        for row in table.rows:
            for cell in row.cells:
                for paragraph in cell.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(8)
        header=table.rows[0]._tr.get_or_add_trPr()
        rep=OxmlElement('w:tblHeader');header.append(rep)
        md=['| '+' | '.join(map(str,df.columns))+' |','| '+' | '.join(['---']*len(df.columns))+' |']
        md+=['| '+' | '.join(str(v).replace('|','／') for v in row)+' |' for row in df.itertuples(index=False,name=None)]
        self.md.append('\n'.join(md));self.web.append(df.to_html(index=False,escape=True,border=0))

    def fig(self,path,caption):
        self.doc.add_picture(str(path),width=Inches(6.55));self.doc.add_paragraph(caption,style='Caption')
        self.md.append(f'![{caption}](figures/{path.name})')
        b64=base64.b64encode(path.read_bytes()).decode()
        self.web.append(f'<figure><img src="data:image/png;base64,{b64}" alt="{html.escape(caption)}"><figcaption>{html.escape(caption)}</figcaption></figure>')

    def save(self):
        self.doc.save(self.out/'DID完整分析报告.docx')
        (self.out/'DID完整分析报告.md').write_text('\n\n'.join(self.md),encoding='utf-8')
        css='''body{font-family:system-ui,"Noto Sans CJK SC",sans-serif;max-width:1120px;margin:36px auto;padding:0 25px;color:#203040;line-height:1.75}h1,h2{color:#174b72}h2{border-bottom:1px solid #cdd8e2;padding-bottom:6px;margin-top:38px}table{border-collapse:collapse;width:100%;font-size:13px;margin:18px 0}td,th{border:1px solid #ccd7e0;padding:7px;text-align:left}th{background:#e9f0f6}img{width:100%;height:auto}figure{margin:25px 0}figcaption{font-size:13px;color:#526575}@media print{h2{page-break-after:avoid}table{font-size:10px}figure{break-inside:avoid}}'''
        (self.out/'DID完整分析报告.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>DID完整分析报告</title><style>'+css+'</style><body>'+'\n'.join(self.web)+'</body></html>',encoding='utf-8')


def regression_table(df):
    return pd.DataFrame({'模型':df.model,'系数':df.beta.map(f),'标准误':df.se.map(f),'p值':df.p.map(pf),
        '95%置信区间':[f'[{f(a)}, {f(b)}]' for a,b in zip(df.ci_low,df.ci_high)],'观测数':df.n.astype(int)})


def plots(out,read,meta):
    folder=out/'figures';folder.mkdir(exist_ok=True)
    fontfile=Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
    if fontfile.exists():
        font_manager.fontManager.addfont(str(fontfile))
        plt.rcParams['font.family']=font_manager.FontProperties(fname=str(fontfile)).get_name()
    plt.rcParams.update({'axes.unicode_minus':False,'figure.dpi':120,'savefig.dpi':220,
        'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,
        'axes.titleweight':'bold','axes.labelcolor':'#334155','axes.edgecolor':'#94a3b8'})
    figs={}
    def save(fig,name):
        fig.tight_layout();fig.savefig(folder/(name+'.png'),bbox_inches='tight')
        fig.savefig(folder/(name+'.pdf'),bbox_inches='tight');plt.close(fig)
        figs[name]=folder/(name+'.png')
    d=read('组别年度均值')
    fig,ax=plt.subplots(figsize=(10,5.2))
    for t,label,color in [(0,'对照组（政策前非重污染）','#2563eb'),(1,'处理组（政策前重污染）','#db6d28')]:
        q=d[d.treat.eq(t)];ax.plot(q.year,q['均值'],marker='o',lw=2.2,color=color,label=label)
        for _,r in q.iterrows():ax.annotate(f'n={int(r.n)}',(r.year,r['均值']),xytext=(0,10 if t==0 else -19),textcoords='offset points',ha='center',fontsize=8,color=color)
    ax.axvline(2011.5,color='#64748b',ls='--');ax.set(xlabel='年份',ylabel='资本错配均值（1%/99%缩尾）',title='组别年度均值：描述性变化')
    ax.legend(loc='upper left');ax.grid(alpha=.15);save(fig,'01_年度趋势')
    fig,axes=plt.subplots(1,2,figsize=(12,4.8),sharey=True)
    for ax,name,title in [(axes[0],'事件研究','主样本'),(axes[1],'事件研究_剔除口径观测','剔除2013疑似口径观测')]:
        q=read(name).query("model == '核心控制'")
        ax.errorbar(q.year,q.beta,yerr=[q.beta-q.ci_low,q.ci_high-q.beta],fmt='o-',capsize=4,color='#2563eb',lw=1.5)
        ax.axhline(0,color='#64748b',lw=1);ax.axvline(2011.5,color='#db6d28',ls='--')
        ax.scatter([2011],[0],marker='s',color='#64748b',zorder=5)
        ax.set(title=title,xlabel='年份',xticks=list(range(2009,2015)));ax.grid(alpha=.15)
    axes[0].set_ylabel('相对于2011年的处理组差异（95%置信区间）')
    save(fig,'02_动态效应与口径敏感性')
    d=read('稳健性检验');d=d[~d.model.eq('log(1+原始Y)')].copy()
    d=pd.concat([read('基准回归').query("model == '双固定效应_核心控制'"),d],ignore_index=True)
    fig,ax=plt.subplots(figsize=(11,8.3));yy=np.arange(len(d))
    ax.errorbar(d.beta,yy,xerr=[d.beta-d.ci_low,d.ci_high-d.beta],fmt='o',capsize=3,color='#2563eb')
    ax.axvline(0,color='#d97706',ls='--');ax.set_yticks(yy,d.model);ax.invert_yaxis()
    ax.set(xlabel='DID系数及95%置信区间（原指标单位）',title='基准与稳健性：主分析未出现稳定的平均效应证据');ax.grid(axis='x',alpha=.2)
    save(fig,'03_稳健性系数图')
    fig,axes=plt.subplots(1,2,figsize=(12,4.6))
    d=read('行业标签置换');b=meta['resampling']['observed_beta']
    axes[0].hist(d.beta,bins=35,color='#93c5fd',edgecolor='white');axes[0].axvline(b,color='#dc2626',lw=2,label=f'观测β={b:.4f}')
    axes[0].set(title=f"行业标签置换（诊断p={meta['resampling']['permutation_diagnostic_p']:.3f}）",xlabel='置换后的DID系数',ylabel='频数');axes[0].legend()
    d=read('行业WildBootstrap');t=meta['resampling']['industry_t']
    axes[1].hist(d.t_null,bins=35,color='#a7f3d0',edgecolor='white');axes[1].axvline(t,color='#dc2626',lw=2,label=f'观测t={t:.3f}')
    axes[1].set(title=f"行业Wild bootstrap（p={meta['resampling']['wild_p']:.3f}）",xlabel='零假设下的t统计量');axes[1].legend()
    save(fig,'04_行业置换与WildBootstrap')
    p=read('PSM平衡性');e=read('熵平衡_平衡性');yy=np.arange(len(p))
    names={'y':'政策前资本错配','size_w':'规模','leverage_w':'杠杆率','roa_w':'ROA','growth_w':'营收增长率','age_w':'年龄','inst_frac_w':'机构持股','hhi_w':'HHI'}
    fig,ax=plt.subplots(figsize=(10,5.6))
    ax.scatter(p.smd_before.abs(),yy,label='调整前',color='#64748b',s=45)
    ax.scatter(p.smd_after.abs(),yy,label='PSM后',color='#db6d28',s=45,marker='s')
    ax.scatter(e.smd_after.abs(),yy,label='熵平衡后（均值）',color='#059669',s=45,marker='D')
    ax.axvline(.1,ls='--',color='#dc2626',label='|SMD|=0.1参考线');ax.set_yticks(yy,p.variable.map(names));ax.invert_yaxis()
    ax.set(xlabel='绝对标准化均值差 |SMD|',title='政策前协变量平衡：检查调整后的逐项差异');ax.legend();ax.grid(axis='x',alpha=.2)
    save(fig,'05_协变量平衡性')
    p=read('PSM倾向得分');fig,axes=plt.subplots(1,2,figsize=(12,4.8),sharex=True)
    bins=np.linspace(0,1,21)
    for i,ax in enumerate(axes):
        for t,label,color in [(0,'对照组','#2563eb'),(1,'处理组','#db6d28')]:
            q=p[p.treat.eq(t)]
            if i: q=q[q.match_weight.gt(0)]
            ax.hist(q.ps,bins=bins,density=True,weights=q.match_weight if i else None,alpha=.45,color=color,label=label)
        ax.set(title='匹配后（计入重复匹配权重）' if i else '匹配前',xlabel='倾向得分',ylabel='密度');ax.legend()
    save(fig,'06_倾向得分分布')
    return figs


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output-dir',type=Path,default=Path('results'));args=ap.parse_args()
    out=args.output_dir
    def read(name):return pd.read_csv(out/'tables'/f'{name}.csv')
    m=json.loads((out/'analysis_metadata.json').read_text())
    fig=plots(out,read,m);r=Report(out)
    base=read('基准回归');core=base.query("model == '双固定效应_核心控制'").iloc[0]
    pretest=read('动态联合检验').query("model == '核心控制' and test == '政策前联合检验'").iloc[0]
    ev=read('事件研究').query("model == '核心控制'")
    ev2013=ev[ev.year.eq(2013)].iloc[0]
    evfix=read('事件研究_剔除口径观测').query("model == '核心控制' and year == 2013").iloc[0]
    evind=read('事件研究_行业聚类').query("model == '核心控制' and year == 2013").iloc[0]
    eb=read('熵平衡_DID');ebcore=eb.query("model == '熵平衡DID_核心控制'").iloc[0]
    r.title('绿色信贷指引与企业资本错配：完整 DID 分析')
    r.p('基于用户提供的 DID 演示代码及两份行业分类工作簿；政策年份2012，观测期2009—2014。结果由随附Python脚本直接计算，报告生成日期2026年10月16日。')
    r.p(f"主分析覆盖{m['main_firms']}家企业、{m['main_n']:,}条企业年度观测，其中重污染处理组{m['treated_firms']}家、对照组{m['control_firms']}家。核心控制模型β={core.beta:.4f}，企业聚类标准误={core.se:.4f}，p={core.p:.3f}，95%置信区间[{core.ci_low:.4f}, {core.ci_high:.4f}]。现有样本未提供稳定证据表明政策显著改变了资本错配的平均水平；不显著也不等于证明政策效应为零。")
    r.p(f"动态效应中，2013年在主样本下为负且按企业聚类显著，但剔除疑似口径观测后p={evfix.p:.3f}，按行业聚类后p={evind.p:.3f}。部分PSM及熵平衡加权设定得到显著负向估计，说明结果依赖权重与指标口径，不能仅挑选显著设定作为政策结论。")
    r.h('一、研究问题与识别设计')
    r.p('沿用演示的研究问题：2012年《绿色信贷指引》出台后，重污染行业企业的资本错配相对其他企业是否变化？政策年份来自用户演示，本分析未另行识别地区分批实施或企业实际获得绿色信贷的时间。')
    r.p('Y_it = β·(Treat_i × Post_t) + γ′X_it + μ_i + λ_t + ε_it。μ_i为企业固定效应，λ_t为年份固定效应；Treat的主效应由企业固定效应吸收，Post的主效应由年份固定效应吸收。Post=1(year≥2012)。β<0表示资本错配绝对值相对下降，单位为原始错配指标单位，不能直接解释为百分比。')
    r.p('主样本仅包含政策前后均可观察的企业。Treat按各企业最后一个可观察的政策前年份（优先2011，其次2010或2009）的行业定义，并对其全部年份保持固定。政策前从未出现的企业无法获得可靠的政策前行业与基线，因此不进入主分析。该估计针对可持续观察企业，不能自动推广到新增或退出样本的企业。')
    r.p('同一时间实施的二元政策采用企业和年份双固定效应。基准不加控制变量的模型用于观察总的条件均值差异；核心模型加入规模、杠杆率、ROA、营收增长率和年龄；扩展模型再加入机构持股和HHI。同期财务变量可能受政策影响，因此控制模型是附加条件下的比较，不自动等于政策总效应。行业×年份固定效应与行业层面的政策变量会共线，本报告不通过加入该项来伪造识别。')
    r.h('二、行业定义、变量与数据处理')
    r.p('重污染关键词严格使用用户提供的21项，按规范化后的二级行业名称做子串匹配，不额外纳入医药或泛化的“采矿”等词。二级行业缺失时使用一级行业；本数据缺失项均为“综合类”，按非重污染处理，并报告剔除此类企业的稳健性结果。')
    from run_did_analysis import KEYWORDS
    r.table(pd.DataFrame({'序号':range(1,len(KEYWORDS)+1),'重污染行业关键词':KEYWORDS}))
    r.p(f"政策前旧行业分类下实际有{m['industry_clusters']}个行业簇，其中{m['treated_industries']}个为处理行业簇。{m['pre_switch_firms']}家主样本企业在政策前的处理状态曾变化；{m['post_disagree_firms']}家企业在政策后的当期关键词分类与固定处理状态存在不一致，共{m['post_disagree_obs']}条观测。它们可能反映行业口径更替或实际业务变化，固定政策前分组可避免直接用政策后分类重新定义处理组，但不能解决所有行业可比性问题。")
    variables=[
        ['企业标识','Stkcd / firm','股票代码统一为6位字符串；不使用股票简称拼接'],
        ['资本错配','mis / y','原表H列；|带符号楔子|；主回归全主样本1%/99%缩尾'],
        ['借贷成本','rit','原表F列；补充结果使用其1%/99%缩尾值'],
        ['企业规模','size','原表J列；已等于资产自然对数，不再取对数'],
        ['杠杆率','leverage','原表K列；保留原数值，回归使用缩尾值'],
        ['盈利能力','roa','原表L列；ROA'],
        ['营收增长','growth','原表M列；营收增长率'],
        ['机构持股','inst_frac','原表N列÷100；100表示100%'],
        ['公司年龄','age','原表O列；已呈对数特征，直接使用'],
        ['行业集中度','hhi','原表P列；原行业口径指标'],
    ]
    r.table(pd.DataFrame(variables,columns=['变量','代码字段','定义与单位']))
    r.p('六张表实际均为16列。演示脚本的硬编码列位置与这些文件不一致，尤其2010、2011及政策后工作表；本分析按已核查的实际结构统一读取。股票代码、日期年份、企业年度唯一性、资本错配与绝对楔子关系均通过检查。原始Excel保持原样，不修改源公式或缓存值。')
    r.p('主分析的Y和所有连续控制变量分别按主样本总体的1%及99%分位数缩尾；子样本敏感性分析沿用主样本阈值以减少同时改变口径。匹配及熵平衡使用政策前数据单独确定缩尾阈值，再计算企业政策前均值，不使用政策后财务表现构建权重。机构持股比例超过100%的观测为0，符合输入文件已筛选的状态。')
    r.h('三、样本审计与指标口径问题')
    r.table(read('样本流程'))
    r.table(read('年度样本'))
    r.p(f"原始数据共{m['raw_n']:,}条、{m['raw_firms']:,}家企业，企业—年份重复数为0，主要数值变量无缺失；二级行业缺失{m['missing_ind2_raw']}条，主分析中有{m['anchor_fallback_firms']}家企业的基期分类使用一级行业。杠杆率大于1有{m['leverage_over_one']}条，并非自动判错；主分析以缩尾控制其极端影响。")
    r.p(f"重点口径核查：2013年批发和零售行业共{m['suspect_raw']}条观测满足wedge=rit−1，因而其资本错配等于|rit−1|，主样本涉及{m['suspect_main']}条。若楔子原定义是rit/行业基准−1，该模式相当于分母为1；目前没有构造公式的完整依据，不能确认这是错误，也不能自行补造行业基准。全部疑似记录的股票代码、Excel行号和原值已列入结果表。")
    r.p('2009—2011与2012—2014行业口径不同，既影响处理组映射，也可能影响以行业基准计算的资本错配指标。应优先核对原始行业均值、归一化基准、借贷成本计算口径和2013年批零行业的数据来源。本文保留原指标，另报告剔除观测、剔除企业及剔除相关行业的结果。')
    r.h('四、描述性统计与2×2比较')
    des=read('描述性统计')
    r.table(pd.DataFrame({'变量':des['名称'],'样本数':des['count'].astype(int),'均值':des['mean'].map(f),
        '标准差':des['std'].map(f),'最小值':des['min'].map(f),'中位数':des['50%'].map(f),'最大值':des['max'].map(f)}))
    r.fig(fig['01_年度趋势'],'图1 主分析样本的年度均值，标签为企业数。非平衡面板中均值也受样本构成影响，不能替代固定效应回归。')
    tw=read('二乘二DID');pivot=tw.pivot(index='treat',columns='post',values='mean')
    r.table(pd.DataFrame({'组别':['对照组','处理组'],'政策前均值':pivot[0].map(f).values,
        '政策后均值':pivot[1].map(f).values,'前后变化':(pivot[1]-pivot[0]).map(f).values}))
    r.p(f"观测等权的2×2 DID为{m['raw_2x2_did']:.4f}，与饱和混合OLS的交互项系数一致。它不吸收企业固定差异；企业进出和年度构成变化使其不必等于双固定效应估计。")
    r.h('五、基准回归')
    r.table(regression_table(base))
    r.p('混合OLS仅含常数、Treat、Post及交互项；其余模型均包含企业和年份固定效应。表中基准标准误按企业聚类，并作有限样本组数修正。具体所有控制变量系数、within R²和模型完整输出分别见Excel“基准全系数”及全部回归详细输出.txt；within R²在含年份固定效应时可以为负，不应视为代码错误。')
    r.p(f"核心模型点估计为{core.beta:.4f}，但置信区间同时包含负向、零和正向效应。无控制和扩展控制模型也未达到常用显著性水平。合理表述是“未获得显著的平均效应证据”，不宜写成“政策显著改善资本配置”或“证明政策无效”。")
    r.h('六、事件研究与平行趋势')
    r.p('事件研究以2011年为参照，分别估计Treat×2009、2010、2012、2013、2014，配合企业、年份固定效应及核心控制变量。下表置信区间和p值采用企业聚类。2011年系数固定为0是归一化条件，并非估计结果。')
    r.table(pd.DataFrame({'年份':ev.year,'相对政策年份':ev.relative_year,'系数':ev.beta.map(f),'标准误':ev.se.map(f),
        'p值':ev.p.map(lambda x:'基期' if pd.isna(x) else pf(x)),
        '95%置信区间':[f'[{f(a)}, {f(b)}]' for a,b in zip(ev.ci_low,ev.ci_high)]}))
    r.table(read('动态联合检验').assign(stat=lambda d:d.stat.map(f),p=lambda d:d.p.map(pf)))
    r.p(f"政策前两项系数联合为零的Wald检验p={pretest.p:.3f}，未拒绝该原假设。政策前只有3个年度、2个可估计领先项，检验功效有限；不能把p>0.05当作平行趋势已经被证明。还需无差异性同期冲击、无预期效应及对照组不受政策外溢等识别条件。")
    r.fig(fig['02_动态效应与口径敏感性'],'图2 动态效应及指标口径敏感性。企业聚类95%置信区间，2011为参照。')
    r.p(f"2013年主样本动态系数为{ev2013.beta:.4f}（p={ev2013.p:.3f}），剔除疑似口径观测后为{evfix.beta:.4f}（p={evfix.p:.3f}）；保留主样本但按政策前行业聚类后p={evind.p:.3f}。2012与2014的主样本动态系数也不显著。原来的2013年单年显著性对口径和推断方式敏感，不能支持稳定的政策改善结论。")
    r.h('七、稳健性检验与行业层面推断')
    r.table(regression_table(read('稳健性检验')))
    r.fig(fig['03_稳健性系数图'],'图3 除log(1+Y)外，均使用原始资本错配指标单位；log规格系数不能与原单位直接比较。')
    r.p('上述稳健性设定均使用核心控制变量，除“政策前协变量均值乘年份”使用基线协变量与年份交互代替同期控制。仅前后行业分类一致的样本使用了政策后信息，可能产生选择偏差，故只作敏感性分析。剔除2012年改变观测窗口；处理组线性趋势改变识别假设；这些估计的目标不完全相同。最早政策前行业定义是对最新政策前行业锚点的替代。')
    r.p(f"政策冲击按行业赋予，企业间同业相关性需要关注。按政策前45个行业簇聚类、使用t(G−1)推断后，核心β不变，标准误={m['resampling']['industry_se_fwl']:.4f}。受限Wild cluster bootstrap采用行业内统一Rademacher权重、999次抽样、双侧t统计量检验，p={m['resampling']['wild_p']:.3f}。处理行业只有7个簇，即使使用重抽样也不消除少量处理簇和行业混杂的问题。")
    r.h('八、时间安慰剂与行业标签置换')
    r.table(regression_table(read('时间安慰剂')))
    r.p('时间安慰剂仅使用2009—2011年真正的政策前数据，将2010或2011设为虚假实施年，并要求企业在对应伪政策前后均可观察；避免把真实政策后年份混入伪政策检验。其显著性检验不是对所有潜在遗漏因素的证明。')
    r.fig(fig['04_行业置换与WildBootstrap'],'图4 左：保持处理行业数量的行业标签置换；右：零假设下行业Wild cluster bootstrap。')
    r.p(f"行业标签置换999次，双侧经验尾部比例为{m['resampling']['permutation_diagnostic_p']:.3f}，采用(1+极端次数)/(1+抽样次数)修正。由于重污染行业并非随机被分配政策，这个比例只作为标签敏感性诊断，不能解释为设计有效的随机化因果p值。随机种子为{m['resampling']['seed']}。")
    r.h('九、PSM-DID、平衡诊断及熵平衡')
    r.p('倾向得分用政策前企业平均资本错配、规模、杠杆率、ROA、增长率、年龄、机构持股和HHI的标准化值估计Logit；先限制处理组与对照组得分的共同支持区间，再按logit得分1:1最近邻有放回匹配，卡尺为全样本logit得分标准差的0.2倍。控制企业被重复匹配时，以匹配次数作为企业各年权重。')
    psm=m['psm']
    r.p(f"共匹配{psm['matched_treated']}家处理企业和{psm['unique_controls']}家不同的对照企业。共同支持区间为[{psm['common_support_low']:.4f},{psm['common_support_high']:.4f}]，logit卡尺={psm['caliper_logit']:.4f}。匹配后最大绝对标准化均值差为{psm['max_abs_smd_after']:.3f}，规模及机构持股两项略高于0.1的常用参考值。总体均值差异已缩小，但尚未达到各项均低于该参考线的目标；PSM不能被描述为完全消除了选择偏差。")
    r.table(regression_table(read('PSM_DID')))
    r.p('PSM核心控制模型在企业聚类下显著为负，但应同时考察行业聚类和固定原匹配权重剔除口径异常后的结果。剔除子样本后没有重新匹配，目的在于单独观察数据口径敏感性；其平衡性不再等于原匹配样本。')
    r.fig(fig['05_协变量平衡性'],'图5 标准化均值差分母固定为调整前两组方差均值的平方根。熵平衡只保证所设均值矩，不保证高阶分布或未观测因素平衡。')
    r.fig(fig['06_倾向得分分布'],'图6 倾向得分分布。仅看得分重叠不足以证明协变量逐项平衡，需结合图5。')
    r.p('针对PSM的平衡不足，补充熵平衡：处理企业权重为1，对照企业以最小化相对均匀权重的熵距离为目标，使上述8个政策前协变量均值与处理组一致；权重计算不使用回归显著性。该方法面向处理组的可比性重加权，但非平衡面板TWFE仍有自身加权结构，不能无条件称为严格识别的总体ATT。')
    e=m['entropy_balancing']
    r.p(f"熵平衡后最大绝对均值SMD约为{e['max_abs_smd_after']:.2e}，控制组权重有效样本量ESS={e['control_ess']:.1f}，单个控制企业最大权重={e['control_weight_max']:.3f}。基准加权核心模型β={ebcore.beta:.4f}（p={ebcore.p:.3f}）。下面同时报告行业聚类和保留原权重剔除疑似口径记录的估计，避免只呈现显著设定；剔除后的子样本不再保证原来的精确均值平衡。")
    r.table(regression_table(eb))
    r.p('PSM和熵平衡的聚类标准误均以已估计权重为给定，未对倾向得分或熵权估计过程做完整的企业级重抽样，也不能排除不可观测混杂。完整事件研究和联合检验在Excel的PSM及熵平衡工作表中。')
    r.h('十、异质性：政策前规模、杠杆和机构持股')
    h=read('异质性_组间正式检验')
    r.p('按政策前企业均值的中位数分组，在同一个全样本回归中加入DID×高组指标和高组×年份交互；正式检验两组系数差，而非根据一组显著、另一组不显著就认定差异。三项组间检验同时报告Benjamini–Hochberg校正p值。')
    r.table(pd.DataFrame({'维度':h.dimension,'低组β':h.beta_low.map(f),'高组β':h.beta_high.map(f),
        '高减低':h.difference.map(f),'组间p':h.p_difference.map(pf),'BH校正p':h.p_difference_BH.map(pf)}))
    r.p('三项正式组间差异检验均未达到5%显著性水平。现有数据没有产权性质、地区等字段，无法进行国企/民企或东中西部异质性分析；报告没有用股票简称猜测这些属性。')
    r.h('十一、借贷成本等补充结果：不等同于机制识别')
    r.table(regression_table(read('补充结果_非机制识别')))
    r.p('借贷成本、杠杆率和企业规模作为单独结果变量估计不加同期控制的双固定效应模型，同时列出企业和行业聚类标准误。这些模型属于探索性补充，尚未逐一完成各自的平行趋势、指标口径和多重检验验证。借贷成本本身参与资本错配指标构造，两者的统计关联不构成独立的中介机制证据；不能据此宣称已验证“信贷约束机制”。正式机制研究还需要融资结构、利息支出、贷款期限或融资约束指标等数据和额外识别假设。')
    r.h('十二、可用于论文初稿的结果表述')
    r.p(f"本文以2012年《绿色信贷指引》为政策背景，基于2009—2014年637家企业的3343条企业年度观测，依据政策前行业及预先给定的重污染行业关键词构造处理组，采用企业和年份双固定效应进行估计。在控制企业规模、杠杆率、ROA、营收增长率和年龄后，DID系数为{core.beta:.4f}（企业聚类标准误{core.se:.4f}，p={core.p:.3f}），尚未获得政策显著改变资本错配平均水平的证据。政策前动态系数联合检验未拒绝零假设，但有限的政策前期数使该检验不能确证平行趋势。2013年的负向动态系数对资本错配指标口径及行业聚类推断敏感；部分PSM和熵平衡加权设定呈现负向显著结果，但主回归及多项常规敏感性设定不显著。总体而言，结论依赖样本权重和指标构造，仍需核验行业口径及资本错配计算过程，暂不宜作稳健的因果改善解释。")
    r.h('十三、识别边界与仍需补充的资料')
    r.p('数据局限包括：输入文件已经剔除机构持股超过100%的企业，无法评估这一筛选的总体选择影响；固定处理状态仍不能完全统一新旧行业分类；主样本限制政策前后可观察，存在存续与观察选择；只有3个政策前年份且处理行业簇仅7个；其他行业也可能受绿色信贷政策影响，对照组并非天然完全未受处理。')
    r.p('最优先补充或核验的是资本错配的计算公式、rit的分子分母、逐年行业归一化基准和2013年批零行业口径。若用于正式论文，还应补充可统一的新旧行业代码对照、产权性质、地区、贷款结构及更长的政策前窗口。未提供的字段与公式没有被编造。没有政策分批实施数据，因此未套用面向错峰处理的估计器。')
    r.h('十四、交付文件、复现方式与验证')
    r.p('DID全套结果表.xlsx包含数据审计、完整回归、动态效应、稳健性、时间安慰剂、999次重抽样、PSM匹配对与平衡性、熵平衡权重和异质性等工作表；DID主分析面板.csv用于复核或导入Stata；全部数据与样本标记.csv保留原始变量与入样标记；figures/提供PNG和可导出的PDF。CSV内股票代码需按字符串读取，以保留前导零。')
    r.p('复现：在交付包根目录运行 python -m venv .venv，激活虚拟环境后执行 pip install -r requirements.txt，再运行 python scripts/run_did_analysis.py --input-dir data --output-dir results，最后运行 python scripts/build_report.py --output-dir results。默认随机种子20261016、重抽样999次。输入Excel和原演示代码均随复现包提供，SHA256记录在analysis_metadata.json。')
    r.p('计算验证包括：读取列结构与年份核查、股票代码和企业年度唯一性、资本错配等于绝对楔子、固定处理状态、主样本均跨政策前后、2×2均值差与饱和OLS一致、通过吸收固定效应的FWL计算与PanelOLS系数及行业聚类标准误一致、主模型变量无缺失。图表及报告直接读取计算结果，未手工修改系数或p值。')
    r.table(pd.DataFrame(list(m['versions'].items()),columns=['运行组件','实际版本']))
    r.save()
    print('已生成Word、HTML、Markdown报告及6组PNG/PDF图。')


if __name__=='__main__':main()
