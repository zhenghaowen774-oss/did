#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""绿色信贷(2012)与资本错配：可复现的完整 DID 分析。

输入为用户提供的两份 Excel；保留原始指标，处理组仅由政策前行业定义。
运行：python scripts/run_did_analysis.py --input-dir data --output-dir results
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import re
from pathlib import Path

os.environ.setdefault('MPLCONFIGDIR', '/tmp/did_matplotlib')
os.environ.setdefault('XDG_CACHE_HOME', '/tmp/did_cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np
import pandas as pd
import pyhdfe
import scipy
from scipy import stats
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests
from linearmodels.panel import PanelOLS

KEYWORDS = [
    '化学原料及化学制品制造业', '化学纤维制造业', '有色金属冶炼及压延加工业',
    '有色金属矿采选业', '橡胶和塑料制品业', '煤炭开采和洗选业', '煤炭采选业',
    '电力、热力生产和供应业', '电力、蒸汽、热水的生产和供应业',
    '皮革、毛皮、羽毛及其制品和制鞋业', '石油、化学、塑胶、塑料',
    '石油加工、炼焦及核燃料加工业', '石油和天然气开采业', '纺织、服装、皮毛',
    '纺织业', '造纸、印刷', '造纸及纸制品业', '金属、非金属',
    '非金属矿物制品业', '黑色金属冶炼及压延加工业', '黑色金属矿采选业',
]
RAW_COLUMNS = ['firm', 'date', 'name', 'ind1', 'ind2', 'rit', 'wedge', 'mis',
               'assets', 'size', 'leverage', 'roa', 'growth', 'inst', 'age', 'hhi']
CORE_RAW = ['size', 'leverage', 'roa', 'growth', 'age']
EXT_RAW = CORE_RAW + ['inst_frac', 'hhi']
CORE = [x + '_w' for x in CORE_RAW]
EXT = [x + '_w' for x in EXT_RAW]
LABELS = {'mis': '资本错配原值', 'y': '资本错配(1%缩尾)', 'rit': '借贷成本rit',
          'size': '规模(资产自然对数)', 'leverage': '杠杆率', 'roa': 'ROA',
          'growth': '营收增长率', 'inst_frac': '机构持股比例(0—1)',
          'age': '公司年龄(原表对数值)', 'hhi': '行业HHI'}
TABLES, MODELS, FIGURES = {}, [], []


def log(s):
    print(s, flush=True)


def norm(s):
    return re.sub(r'\s+', '', str(s)).replace('，', '、').replace(',', '、')


def load_panel(input_dir, output_dir):
    frames, files = [], []
    for period, years in [('2009-2011', range(2009, 2012)), ('2012-2014', range(2012, 2015))]:
        paths = list(input_dir.glob(f'*{period}*.xlsx'))
        if len(paths) != 1:
            raise ValueError(f'{period} 要求恰好一个输入文件，找到 {len(paths)} 个')
        p = paths[0]
        files.append({'file': p.name, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()})
        for year in years:
            raw = pd.read_excel(p, sheet_name=str(year), header=None)
            if raw.shape[1] != 16:
                raise ValueError(f'{p.name}/{year}: 预期16列，实际{raw.shape[1]}列，请重新审查结构')
            # 六个工作表经人工核查均为统一的16列；部分表头空白，不能使用演示的旧位置映射。
            d = raw.iloc[1:].copy()
            d.columns = RAW_COLUMNS
            codes = pd.to_numeric(d['firm'], errors='coerce')
            if codes.isna().any() or ((codes % 1) != 0).any():
                raise ValueError('发现无法解析的股票代码')
            d['firm'] = codes.astype(int).astype(str).str.zfill(6)
            d['date'] = pd.to_datetime(d['date'], errors='raise')
            if not d['date'].dt.year.eq(year).all():
                raise ValueError('工作表年份与日期不一致')
            for c in RAW_COLUMNS[5:]:
                d[c] = pd.to_numeric(d[c], errors='coerce').replace([np.inf, -np.inf], np.nan)
            d['year'] = year
            d['source_file'], d['source_sheet'] = p.name, str(year)
            d['source_excel_row'] = np.arange(2, len(d) + 2)
            frames.append(d)
    d = pd.concat(frames, ignore_index=True).sort_values(['firm', 'year']).reset_index(drop=True)
    if d.duplicated(['firm', 'year']).any():
        raise ValueError('发现重复企业—年份，请人工审查，不自动去重')
    if not np.allclose(d['mis'], d['wedge'].abs(), equal_nan=True, rtol=1e-8, atol=1e-8):
        raise ValueError('资本错配列与带符号楔子绝对值不一致')
    d['industry_fallback'] = d['ind2'].isna()
    d['industry_used'] = d['ind2'].fillna(d['ind1']).map(norm)
    d['keywords_hit'] = d['industry_used'].map(lambda x: '|'.join(k for k in KEYWORDS if norm(k) in x))
    d['treat_current'] = d['keywords_hit'].ne('').astype(int)
    d['post'] = d['year'].ge(2012).astype(int)
    d['inst_frac'] = d['inst'] / 100.0
    d['suspect_2013'] = d['year'].eq(2013) & np.isclose(d['wedge'], d['rit'] - 1, rtol=1e-8, atol=1e-8)
    pre = d[d['post'].eq(0)]
    anchors = pre.sort_values('year').groupby('firm').tail(1)[
        ['firm', 'year', 'industry_used', 'treat_current', 'industry_fallback']].rename(columns={
            'year': 'anchor_year', 'industry_used': 'industry_pre',
            'treat_current': 'treat', 'industry_fallback': 'anchor_fallback'})
    spans = d.groupby('firm')['post'].nunique()
    pre_switch = pre.groupby('firm')['treat_current'].nunique().gt(1)
    d = d.merge(anchors, on='firm', how='left', validate='many_to_one')
    d['cross_period'] = d['firm'].map(spans).eq(2)
    d['pre_treatment_switch'] = d['firm'].map(pre_switch).astype('boolean').fillna(False).astype(bool)
    d['main_sample'] = d['cross_period'] & d['treat'].notna()
    d['did'] = d['treat'] * d['post']
    main = d[d['main_sample']].copy()
    main['treat'] = main['treat'].astype(int)
    thresholds = []
    for c in ['mis', 'rit'] + EXT_RAW:
        lo, hi = main[c].quantile([.01, .99])
        name = 'y' if c == 'mis' else c + '_w'
        main[name] = main[c].clip(lo, hi)
        thresholds.append({'variable': c, 'lower': lo, 'upper': hi,
                           'clipped_n': int(((main[c] < lo) | (main[c] > hi)).sum())})
    main['y_log'] = np.log1p(main['mis'])
    lo5, hi5 = main['mis'].quantile([.05, .95])
    main['y_w5'] = main['mis'].clip(lo5, hi5)
    main['balanced'] = main['firm'].map(main.groupby('firm')['year'].nunique()).eq(6)
    main['never_current_switch'] = main.groupby('firm')['treat_current'].transform('nunique').eq(1)
    main['classification_agrees'] = main.groupby('firm')['treat_current'].transform('first').eq(main['treat'])
    main['industry_cluster'] = pd.factorize(main['industry_pre'], sort=True)[0]
    d.to_csv(output_dir / '全部数据与样本标记.csv', index=False, encoding='utf-8-sig')
    main.to_csv(output_dir / 'DID主分析面板.csv', index=False, encoding='utf-8-sig')
    TABLES['缩尾阈值'] = pd.DataFrame(thresholds)
    TABLES['年度样本'] = d.groupby('year').agg(观测数=('firm', 'size'), 企业数=('firm', 'nunique'),
        当年重污染数=('treat_current', 'sum'), 主分析观测=('main_sample', 'sum'),
        二级行业缺失=('industry_fallback', 'sum')).reset_index()
    TABLES['行业匹配审计'] = d.groupby(['year', 'ind1', 'ind2', 'industry_used', 'keywords_hit',
        'treat_current'], dropna=False).agg(观测数=('firm', 'size')).reset_index()
    TABLES['行业定义变化'] = main[main['post'].eq(1)].groupby(
        ['industry_pre', 'industry_used', 'treat', 'treat_current']).agg(
            观测数=('firm', 'size'), 企业数=('firm', 'nunique')).reset_index()
    TABLES['关键词覆盖'] = pd.DataFrame([{'关键词': k, '全样本匹配观测': int(d['industry_used'].map(
        lambda x: norm(k) in x).sum())} for k in KEYWORDS])
    TABLES['疑似指标口径记录'] = d[d['suspect_2013']][['firm','year','name','ind1','ind2','rit','wedge',
        'mis','main_sample','source_file','source_excel_row']]
    TABLES['缺失值审计'] = pd.DataFrame({'变量': d.columns, '缺失数': d.isna().sum().values})
    TABLES['样本流程'] = pd.DataFrame([
        {'步骤':'原始六年数据','观测数':len(d),'企业数':d.firm.nunique()},
        {'步骤':'仅政策后出现，缺政策前行业与基线，排除','观测数':int(d.treat.isna().sum()),
         '企业数':d.loc[d.treat.isna(),'firm'].nunique()},
        {'步骤':'仅政策前出现，排除','观测数':int((~d.cross_period & d.post.eq(0)).sum()),
         '企业数':d.loc[~d.cross_period & d.post.eq(0),'firm'].nunique()},
        {'步骤':'主样本：政策前后均可观察','观测数':len(main),'企业数':main.firm.nunique()},
        {'步骤':'其中六年平衡面板','观测数':int(main.balanced.sum()),
         '企业数':main.loc[main.balanced,'firm'].nunique()},
    ])
    TABLES['企业分类锚点'] = anchors.merge(
        main.groupby('firm').agg(主样本观测数=('year','size')), on='firm', how='left')
    meta = {'inputs':files, 'raw_n':len(d), 'raw_firms':d.firm.nunique(),
        'main_n':len(main), 'main_firms':main.firm.nunique(),
        'treated_firms':main.loc[main.treat.eq(1),'firm'].nunique(),
        'control_firms':main.loc[main.treat.eq(0),'firm'].nunique(),
        'balanced_firms':main.loc[main.balanced,'firm'].nunique(),
        'pre_switch_firms':main.loc[main.pre_treatment_switch,'firm'].nunique(),
        'post_disagree_firms':main.loc[main.post.eq(1) & main.treat.ne(main.treat_current),'firm'].nunique(),
        'post_disagree_obs':int((main.post.eq(1) & main.treat.ne(main.treat_current)).sum()),
        'suspect_raw':int(d.suspect_2013.sum()), 'suspect_main':int(main.suspect_2013.sum()),
        'missing_ind2_raw':int(d.industry_fallback.sum()),
        'anchor_fallback_firms':main.loc[main.anchor_fallback.eq(True),'firm'].nunique(),
        'industry_clusters':main.industry_pre.nunique(),
        'treated_industries':main.loc[main.treat.eq(1),'industry_pre'].nunique(),
        'leverage_over_one':int(d.leverage.gt(1).sum()),
        'age_is_log':bool(np.allclose(np.exp(d.age), np.exp(d.age).round(), atol=1e-5)),
        'inst_over100':int(d.inst.gt(100).sum()), 'duplicate_firm_year':int(d.duplicated(['firm','year']).sum())}
    return d, main, meta


def fe(data, label, y='y', controls=CORE, extra=None, cluster='firm', weights=None, did='did'):
    regressors = [did] + list(controls) + list(extra or [])
    need = ['firm','year',y] + regressors + (['industry_cluster'] if cluster == 'industry' else [])
    z = data.dropna(subset=need).copy().sort_values(['firm','year']).set_index(['firm','year'])
    mod = PanelOLS(z[y], z[regressors], entity_effects=True, time_effects=True,
                   weights=None if weights is None else z[weights], drop_absorbed=True)
    if cluster == 'industry':
        result = mod.fit(cov_type='clustered', clusters=z[['industry_cluster']], group_debias=True)
    else:
        result = mod.fit(cov_type='clustered', cluster_entity=True, group_debias=True)
    b, se = result.params[did], result.std_errors[did]
    groups = z['industry_cluster'].nunique() if cluster == 'industry' else z.index.get_level_values(0).nunique()
    df_p = groups - 1 if cluster == 'industry' else result.df_resid
    p = float(2 * stats.t.sf(abs(b/se), df_p))
    q = stats.t.ppf(.975, df_p)
    row = dict(model=label, outcome=y, beta=float(b), se=float(se), t=float(b/se), p=p,
               ci_low=float(b-q*se), ci_high=float(b+q*se), n=int(result.nobs),
               firms=int(z.index.get_level_values(0).nunique()), cluster=cluster, clusters=int(groups),
               controls=','.join(controls), r2_within=float(result.rsquared_within))
    MODELS.append((label, result))
    return row, result


def describe(main):
    variables = ['mis','y','rit'] + EXT_RAW
    summary = main[variables].describe(percentiles=[.01,.25,.5,.75,.99]).T.reset_index(names='变量')
    summary.insert(1, '名称', summary['变量'].map(LABELS))
    TABLES['描述性统计'] = summary
    TABLES['组别年度均值'] = main.groupby(['treat','year']).agg(
        n=('firm','size'),均值=('y','mean'),标准差=('y','std'),原始均值=('mis','mean')).reset_index()
    tab = main.groupby(['treat','post']).agg(mean=('y','mean'),n=('firm','size')).reset_index()
    TABLES['二乘二DID'] = tab
    m = tab.set_index(['treat','post'])['mean']
    raw_did = (m[1,1]-m[1,0])-(m[0,1]-m[0,0])
    TABLES['变量相关矩阵'] = main[['y']+[x+'_w' for x in EXT_RAW]].corr().reset_index(names='variable')
    return float(raw_did)


def baselines(main):
    X = sm.add_constant(main[['treat','post','did']])
    ols = sm.OLS(main.y,X).fit(cov_type='cluster', cov_kwds={'groups':main.firm})
    ci = ols.conf_int().loc['did']
    rows=[dict(model='混合OLS_2x2',outcome='y',beta=ols.params['did'],se=ols.bse['did'],
        t=ols.tvalues['did'],p=ols.pvalues['did'],ci_low=ci.iloc[0],ci_high=ci.iloc[1],
        n=int(ols.nobs),firms=main.firm.nunique(),cluster='firm',clusters=main.firm.nunique(),
        controls='treat,post',r2_within=np.nan)]
    results={}
    for label,controls in [('双固定效应_无控制',[]),('双固定效应_核心控制',CORE),('双固定效应_扩展控制',EXT)]:
        row, res=fe(main,label,controls=controls)
        rows.append(row); results[label]=res
    TABLES['基准回归']=pd.DataFrame(rows)
    coeff=[]
    for label,res in results.items():
        for var in res.params.index:
            coeff.append(dict(model=label,variable=var,beta=res.params[var],se=res.std_errors[var],
                              p=res.pvalues[var],n=res.nobs))
    TABLES['基准全系数']=pd.DataFrame(coeff)
    return results


def event_study(main, suffix='', weights=None, cluster='firm'):
    d=main.copy(); names=[]
    for year in [2009,2010,2012,2013,2014]:
        name=f'event_{year}'; d[name]=d['treat']*d.year.eq(year); names.append(name)
    rows=[]; tests=[]
    for label,controls in [('无控制',[]),('核心控制',CORE)]:
        _,res=fe(d,'动态效应_'+label+suffix,controls=controls,did=names[0],extra=names[1:],weights=weights,cluster=cluster)
        dfp=d.industry_pre.nunique()-1 if cluster=='industry' else res.df_resid
        crit=stats.t.ppf(.975,dfp)
        for year in range(2009,2015):
            name=f'event_{year}'
            if year==2011:
                rows.append(dict(model=label,year=year,relative_year=-1,beta=0.,se=0.,p=np.nan,
                                 ci_low=0.,ci_high=0.,reference=True))
            else:
                b,se=res.params[name],res.std_errors[name]
                rows.append(dict(model=label,year=year,relative_year=year-2012,beta=res.params[name],
                    se=se,p=2*stats.t.sf(abs(b/se),dfp),ci_low=b-crit*se,ci_high=b+crit*se,reference=False))
        for kind,vs in [('政策前联合检验',['event_2009','event_2010']),
                        ('政策后联合检验',['event_2012','event_2013','event_2014'])]:
            r=np.zeros((len(vs),len(res.params)))
            for i,v in enumerate(vs): r[i,list(res.params.index).index(v)]=1
            test=res.wald_test(r)
            p=stats.f.sf(test.stat/len(vs),len(vs),dfp) if cluster=='industry' else test.pval
            tests.append(dict(model=label,test=kind,stat=float(test.stat),df=len(vs),p=float(p),
                distribution='F(Wald/q,G-1)近似' if cluster=='industry' else 'chi2'))
    TABLES['事件研究'+suffix]=pd.DataFrame(rows)
    TABLES['动态联合检验'+suffix]=pd.DataFrame(tests)
    return rows, tests


def robustness(main):
    rows=[]
    def add(label,data=main,**kwargs):
        row,_=fe(data,label,**kwargs); rows.append(row)
    add('不缩尾Y',y='mis')
    add('Y缩尾5%与95%',y='y_w5')
    add('log(1+原始Y)',y='y_log')
    add('六年平衡面板',main[main.balanced])
    add('剔除政策实施年2012',main[main.year.ne(2012)])
    add('剔除2013疑似口径观测',main[~main.suspect_2013])
    suspicious_firms=main.loc[main.suspect_2013,'firm'].unique()
    add('剔除疑似口径企业全部年份',main[~main.firm.isin(suspicious_firms)])
    wholesale=main.industry_pre.str.contains('零售|批发|商业经纪',regex=True)
    add('剔除政策前批发零售相关行业',main[~wholesale])
    add('仅政策前处理状态稳定',main[~main.pre_treatment_switch])
    add('仅前后分类均一致_选择性子样本',main[main.never_current_switch & main.classification_agrees])
    add('剔除基期二级行业缺失',main[~main.anchor_fallback.astype(bool)])
    add('政策前行业聚类',cluster='industry')
    d=main.copy(); d['treat_trend']=d.treat*(d.year-2011)
    add('控制处理组线性时间趋势',d,extra=['treat_trend'])
    # 政策前变量与年份交互：不依赖当期可能受政策影响的控制变量。
    premean=main[main.post.eq(0)].groupby('firm')[CORE].mean().add_suffix('_premean')
    d=main.merge(premean,on='firm',how='left'); ex=[]
    for c in CORE:
        for yr in range(2010,2015):
            name=f'{c}_pre_x_{yr}';d[name]=d[c+'_premean']*d.year.eq(yr);ex.append(name)
    add('政策前协变量均值乘年份',d,controls=[],extra=ex)
    # 最新的政策前年份 vs 最早的政策前年份；不使用政策后信息定义处理。
    earliest=main[main.post.eq(0)].sort_values('year').groupby('firm').first()['treat_current']
    d=main.copy(); d['treat']=d.firm.map(earliest);d['did']=d.treat*d.post
    add('最早政策前行业固定处理',d)
    TABLES['稳健性检验']=pd.DataFrame(rows)


def placebo_time(main):
    rows=[]
    for year in [2010,2011]:
        d=main[main.year.lt(2012)].copy();d['fake_post']=d.year.ge(year).astype(int)
        valid=d.groupby('firm').fake_post.nunique().eq(2)
        d=d[d.firm.isin(valid[valid].index)].copy();d['fake_did']=d.treat*d.fake_post
        row,_=fe(d,f'伪政策{year}_仅2009至2011',did='fake_did')
        rows.append(row)
    TABLES['时间安慰剂']=pd.DataFrame(rows)


def residualizer(main):
    d=main.sort_values(['firm','year']).copy()
    ids=np.column_stack([pd.factorize(d.firm)[0],d.year.to_numpy()])
    absorb=pyhdfe.create(ids,drop_singletons=False)
    C=absorb.residualize(d[CORE].to_numpy(dtype=float))
    cp=np.linalg.pinv(C)
    def residualize(v):
        a=absorb.residualize(np.asarray(v,dtype=float))
        return a-C@(cp@a)
    return d,residualize


def randomization_checks(main, result, reps, seed):
    d,residualize=residualizer(main)
    y=residualize(d[['y']].to_numpy())[:,0]
    x=residualize(d[['did']].to_numpy())[:,0]
    denom=x@x; b=x@y/denom
    if not np.isclose(b,result.params['did'],atol=1e-9):
        raise AssertionError('FWL与PanelOLS系数不一致')
    group,grouplabel=pd.factorize(d.industry_pre,sort=True);G=len(grouplabel)
    n=len(d); df=result.df_resid
    # 与PanelOLS相同的残差自由度和group_debias修正，行业聚类CR1。
    factor=(n/df)*(G/(G-1))*((n-1)/n)
    def group_sum(v):
        out=np.zeros((G,v.shape[1]))
        np.add.at(out,group,v)
        return out
    errors=y-b*x
    scores=group_sum((x*errors)[:,None])[:,0]
    se=np.sqrt(factor*np.sum(scores**2))/denom
    t=b/se
    # H0: beta=0，受限残差由FE及核心控制变量模型得到。组内统一Rademacher权重。
    EY=np.zeros((n,G));EY[np.arange(n),group]=y
    R=residualize(EY)
    beta_by_group=(x@R)/denom
    score_by_group=group_sum(x[:,None]*R)-group_sum((x*x)[:,None])*beta_by_group[None,:]
    rng=np.random.default_rng(seed)
    W=rng.choice([-1.,1.],size=(G,reps))
    bs=beta_by_group@W
    ses=np.sqrt(factor*np.sum((score_by_group@W)**2,axis=0))/denom
    ts=bs/ses
    wild_p=(1+np.sum(np.abs(ts)>=abs(t)))/(reps+1)
    TABLES['行业WildBootstrap']=pd.DataFrame({'iteration':np.arange(1,reps+1),'beta_null':bs,'t_null':ts})
    # 行业标签置换只作敏感性诊断；行业并非随机获配政策。
    gt=d.groupby('industry_pre').treat.first().reindex(grouplabel).to_numpy()
    permutations=[]
    for start in range(0,reps,100):
        k=min(100,reps-start)
        assigned=np.column_stack([rng.permutation(gt) for _ in range(k)])
        P=assigned[group,:]*d.post.to_numpy()[:,None]
        xp=residualize(P)
        bp=(y@xp)/np.sum(xp*xp,axis=0)
        permutations.extend(bp.tolist())
    permutations=np.asarray(permutations)
    perm_p=(1+np.sum(np.abs(permutations)>=abs(b)))/(reps+1)
    TABLES['行业标签置换']=pd.DataFrame({'iteration':np.arange(1,reps+1),'beta':permutations})
    info=dict(reps=reps,seed=seed,observed_beta=b,industry_clusters=G,industry_se_fwl=se,
              industry_t=t,wild_p=float(wild_p),permutation_diagnostic_p=float(perm_p))
    TABLES['重抽样摘要']=pd.DataFrame([info])
    return info


def matching_pre_covariates(main):
    pre=main[main.post.eq(0)].copy();thresholds=[]
    for raw in ['mis']+EXT_RAW:
        lo,hi=pre[raw].quantile([.01,.99])
        name='y' if raw=='mis' else raw+'_w'
        pre[name]=pre[raw].clip(lo,hi)
        thresholds.append(dict(variable=raw,lower=lo,upper=hi))
    TABLES['匹配政策前缩尾阈值']=pd.DataFrame(thresholds)
    covs=['y']+CORE+['inst_frac_w','hhi_w']
    out=pre.groupby('firm')[covs].mean()
    out['treat']=main.groupby('firm').treat.first()
    return out,covs


def psm_did(main):
    pre,covs=matching_pre_covariates(main)
    X=sm.add_constant((pre[covs]-pre[covs].mean())/pre[covs].std())
    fit=sm.GLM(pre.treat,X,family=sm.families.Binomial()).fit(maxiter=200)
    if not fit.converged: raise RuntimeError('倾向得分模型未收敛')
    pre['ps']=fit.predict(X).clip(1e-8,1-1e-8)
    pre['logit']=np.log(pre.ps/(1-pre.ps))
    t=pre[pre.treat.eq(1)];c=pre[pre.treat.eq(0)]
    lo=max(t.ps.min(),c.ps.min());hi=min(t.ps.max(),c.ps.max())
    pre['support']=pre.ps.between(lo,hi)
    caliper=.2*pre.logit.std(ddof=1)
    controls=pre[pre.treat.eq(0)&pre.support].sort_index()
    pairs=[]
    for firm,row in pre[pre.treat.eq(1)&pre.support].sort_index().iterrows():
        distances=(controls.logit-row.logit).abs();other=distances.idxmin();distance=distances.loc[other]
        if distance<=caliper:
            pairs.append(dict(treated=firm,control=other,distance=distance,treated_ps=row.ps,
                              control_ps=controls.loc[other,'ps']))
    pairs=pd.DataFrame(pairs)
    if len(pairs)<10: raise RuntimeError('匹配成功样本过少')
    weights=pd.concat([pairs.treated.value_counts(),pairs.control.value_counts()]).groupby(level=0).sum()
    pre['match_weight']=pre.index.map(weights).fillna(0).astype(float)
    def weighted_mean(a,w): return np.average(a,weights=w)
    bal=[]
    for var in covs:
        denom=np.sqrt((t[var].var(ddof=1)+c[var].var(ddof=1))/2)
        mt=pre[pre.treat.eq(1)&pre.match_weight.gt(0)];mc=pre[pre.treat.eq(0)&pre.match_weight.gt(0)]
        after=(weighted_mean(mt[var],mt.match_weight)-weighted_mean(mc[var],mc.match_weight))/denom
        bal.append(dict(variable=var,smd_before=(t[var].mean()-c[var].mean())/denom,smd_after=after))
    d=main[main.firm.isin(weights.index)].copy();d['match_weight']=d.firm.map(weights)
    rows=[]
    for label,controls0 in [('PSM_DID_无控制',[]),('PSM_DID_核心控制',CORE)]:
        row,_=fe(d,label,controls=controls0,weights='match_weight');rows.append(row)
    row,_=fe(d,'PSM_DID_行业聚类',weights='match_weight',cluster='industry');rows.append(row)
    row,_=fe(d[~d.suspect_2013],'PSM_DID_固定匹配剔除口径观测',weights='match_weight');rows.append(row)
    suspect_firms=d.loc[d.suspect_2013,'firm'].unique()
    row,_=fe(d[~d.firm.isin(suspect_firms)],'PSM_DID_固定匹配剔除口径企业',weights='match_weight');rows.append(row)
    TABLES['PSM倾向得分']=pre.reset_index()
    TABLES['PSM匹配对']=pairs
    TABLES['PSM平衡性']=pd.DataFrame(bal)
    TABLES['PSM_DID']=pd.DataFrame(rows)
    event_study(d,suffix='_PSM',weights='match_weight')
    return dict(matched_treated=len(pairs),unique_controls=pairs.control.nunique(),
                common_support_low=lo,common_support_high=hi,caliper_logit=caliper,
                outside_support=int((~pre.support).sum()),
                max_abs_smd_after=float(pd.DataFrame(bal).smd_after.abs().max()))


def heterogeneity(main):
    rows=[]
    for var,label in [('size_w','政策前规模'),('leverage_w','政策前杠杆'),('inst_frac_w','政策前机构持股')]:
        means=main[main.post.eq(0)].groupby('firm')[var].mean();median=means.median()
        d=main.copy();d['high']=d.firm.map(means).ge(median).astype(int)
        d['did_high']=d.did*d.high
        extras=['did_high']
        for yr in range(2010,2015):
            col=f'group_year_{yr}';d[col]=d.high*d.year.eq(yr);extras.append(col)
        _,res=fe(d,'异质性_'+label,extra=extras)
        low=res.params['did'];delta=res.params['did_high'];high=low+delta
        cov=res.cov
        se_high=np.sqrt(cov.loc['did','did']+cov.loc['did_high','did_high']+2*cov.loc['did','did_high'])
        rows.append(dict(dimension=label,median=median,beta_low=low,se_low=res.std_errors['did'],
                         beta_high=high,se_high=se_high,difference=delta,se_difference=res.std_errors['did_high'],
                         p_difference=res.pvalues['did_high'],n=res.nobs,
                         low_firms=d.loc[d.high.eq(0),'firm'].nunique(),high_firms=d.loc[d.high.eq(1),'firm'].nunique()))
    out=pd.DataFrame(rows)
    out['p_difference_BH']=multipletests(out.p_difference,method='fdr_bh')[1]
    TABLES['异质性_组间正式检验']=out


def supplementary_outcomes(main):
    rows=[]
    # 补充结果不加可能处于政策传导路径上的当期控制变量。
    for y,label in [('rit_w','借贷成本rit'),('leverage_w','杠杆率'),('size_w','企业规模')]:
        row,_=fe(main,'补充结果_'+label,y=y,controls=[]);rows.append(row)
        row,_=fe(main,'补充结果_'+label+'_行业聚类',y=y,controls=[],cluster='industry');rows.append(row)
    TABLES['补充结果_非机制识别']=pd.DataFrame(rows)


def entropy_balancing(main):
    """ATT熵平衡：控制组政策前协变量均值匹配处理组，只按平衡性确定权重。"""
    from scipy.optimize import minimize
    pre,covs=matching_pre_covariates(main)
    treated=pre[pre.treat.eq(1)];control=pre[pre.treat.eq(0)]
    scale=pre[covs].std().to_numpy()
    z=(control[covs].to_numpy()-treated[covs].mean().to_numpy())/scale
    def fun(theta):
        a=z@theta;shift=a.max();ee=np.exp(a-shift);prob=ee/ee.sum()
        objective=shift+np.log(ee.mean())
        gradient=prob@z
        hessian=(z*prob[:,None]).T@z-np.outer(gradient,gradient)
        return objective,gradient,hessian
    opt=minimize(lambda v:fun(v)[0],np.zeros(len(covs)),jac=lambda v:fun(v)[1],
                 hess=lambda v:fun(v)[2],method='trust-exact',options={'gtol':1e-10,'maxiter':1000})
    if np.max(np.abs(fun(opt.x)[1]))>1e-6: raise RuntimeError('熵平衡未达到预设矩约束')
    a=z@opt.x;a-=a.max();cw=np.exp(a);cw=cw/cw.sum()*len(treated)
    pre['eb_weight']=1.
    pre.loc[control.index,'eb_weight']=cw
    bal=[]
    for var in covs:
        den=np.sqrt((treated[var].var()+control[var].var())/2)
        bal.append(dict(variable=var,smd_before=(treated[var].mean()-control[var].mean())/den,
            smd_after=(treated[var].mean()-np.average(control[var],weights=cw))/den))
    d=main.copy();d['eb_weight']=d.firm.map(pre.eb_weight)
    rows=[]
    for label,controls in [('熵平衡DID_无控制',[]),('熵平衡DID_核心控制',CORE)]:
        row,_=fe(d,label,controls=controls,weights='eb_weight');rows.append(row)
    row,_=fe(d,'熵平衡DID_行业聚类',weights='eb_weight',cluster='industry');rows.append(row)
    row,_=fe(d[~d.suspect_2013],'熵平衡DID_固定权重剔除口径观测',weights='eb_weight');rows.append(row)
    suspect_firms=d.loc[d.suspect_2013,'firm'].unique()
    row,_=fe(d[~d.firm.isin(suspect_firms)],'熵平衡DID_固定权重剔除口径企业',weights='eb_weight');rows.append(row)
    TABLES['熵平衡_DID']=pd.DataFrame(rows)
    TABLES['熵平衡_平衡性']=pd.DataFrame(bal)
    TABLES['熵平衡_企业权重']=pre.reset_index()
    event_study(d,suffix='_熵平衡',weights='eb_weight')
    return dict(control_ess=float(cw.sum()**2/(cw@cw)),control_weight_max=float(cw.max()),
        control_weight_median=float(np.median(cw)),control_weight_min=float(cw.min()),
        max_abs_smd_after=float(pd.DataFrame(bal).smd_after.abs().max()),
        mean_moments_max_error=float(np.max(np.abs(fun(opt.x)[1]))))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir',type=Path,default=Path('data'))
    parser.add_argument('--output-dir',type=Path,default=Path('results'))
    parser.add_argument('--reps',type=int,default=999)
    parser.add_argument('--seed',type=int,default=20261016)
    args=parser.parse_args()
    args.output_dir.mkdir(parents=True,exist_ok=True)
    log('读取数据并审计...')
    raw,panel,meta=load_panel(args.input_dir,args.output_dir)
    log(json.dumps(meta,ensure_ascii=False,indent=2))
    meta['raw_2x2_did']=describe(panel)
    log('基准回归...')
    results=baselines(panel)
    log(TABLES['基准回归'][['model','beta','se','p','n']].to_string(index=False))
    log('动态效应、稳健性与时间安慰剂...')
    event_study(panel)
    event_study(panel[~panel.suspect_2013],suffix='_剔除口径观测')
    suspect_firms=panel.loc[panel.suspect_2013,'firm'].unique()
    event_study(panel[~panel.firm.isin(suspect_firms)],suffix='_剔除口径企业')
    event_study(panel,suffix='_行业聚类',cluster='industry')
    robustness(panel)
    placebo_time(panel)
    log('行业层级Wild cluster bootstrap及标签置换...')
    meta['resampling']=randomization_checks(panel,results['双固定效应_核心控制'],args.reps,args.seed)
    industry_row=TABLES['稳健性检验'].query("model == '政策前行业聚类'").iloc[0]
    if not np.isclose(meta['resampling']['industry_se_fwl'],industry_row.se,rtol=1e-7):
        raise AssertionError('自编FWL聚类标准误与PanelOLS不一致')
    log('PSM-DID及平衡性检查...')
    meta['psm']=psm_did(panel)
    log('熵平衡加权DID...')
    meta['entropy_balancing']=entropy_balancing(panel)
    log('异质性与补充结果...')
    heterogeneity(panel)
    supplementary_outcomes(panel)
    # 内部一致性验证针对关键计量实现，防止错误列映射与统计计算混入最终结果。
    if not np.isclose(meta['raw_2x2_did'],TABLES['基准回归'].iloc[0].beta,atol=1e-10):
        raise AssertionError('2x2均值差与饱和OLS结果不一致')
    if not panel.groupby('firm').treat.nunique().eq(1).all():
        raise AssertionError('处理组必须固定')
    if panel[['y']+EXT].isna().any().any():
        raise AssertionError('主样本仍有缺失变量')
    if not panel.groupby('firm').post.nunique().eq(2).all():
        raise AssertionError('主样本必须跨政策前后')
    csvdir=args.output_dir/'tables';csvdir.mkdir(exist_ok=True)
    with pd.ExcelWriter(args.output_dir/'DID全套结果表.xlsx',engine='openpyxl') as writer:
        for name,table in TABLES.items():
            table.to_excel(writer,sheet_name=name[:31],index=False)
            table.to_csv(csvdir/f'{name}.csv',index=False,encoding='utf-8-sig')
            ws=writer.sheets[name[:31]];ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
            from openpyxl.styles import Font,PatternFill
            for cell in ws[1]:
                cell.font=Font(bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='1F4E78')
            for col in ws.columns:
                vals=[str(c.value or '') for c in list(col)[:100]]
                ws.column_dimensions[col[0].column_letter].width=min(42,max(13,max(map(len,vals))+2))
    with (args.output_dir/'全部回归详细输出.txt').open('w',encoding='utf-8') as f:
        for name,res in MODELS:
            f.write('\n'+name+'\n'+'='*80+'\n'+str(res.summary)+'\n')
    import linearmodels,statsmodels,openpyxl
    meta['versions']={m.__name__:m.__version__ for m in [np,pd,scipy,linearmodels,statsmodels,openpyxl]}
    meta['versions']['python']=platform.python_version()
    meta['internal_validation']=['Excel股票代码和日期校验通过','企业年度无重复',
        '绝对楔子与资本错配列一致','处理组固定且均有政策前后观测',
        '2×2均值差等于饱和OLS交互项','FWL系数与PanelOLS一致',
        'FWL行业聚类标准误与PanelOLS一致','主样本回归变量无缺失']
    (args.output_dir/'analysis_metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2,default=lambda x:x.item()),encoding='utf-8')
    log('完成：'+str(args.output_dir.resolve()))
    log(TABLES['动态联合检验'].to_string(index=False))
    log(TABLES['稳健性检验'][['model','beta','se','p','n']].to_string(index=False))
    log(json.dumps(meta['resampling'],ensure_ascii=False))


if __name__=='__main__':
    main()
